from app.routes import accounts, transactions
# Instead of having to specify the full path each time